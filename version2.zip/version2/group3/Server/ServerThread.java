package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * Creates a thread to handle a client socket connection
 * @author Thomas Baker
 *
 */
public class ServerThread extends Thread {

	private final Socket clientSocket;
	
	public ServerThread(Socket clientSocket) {
		
		this.clientSocket = clientSocket;
	}
	
	@Override
	public void run() {
		try {
			handleClientSocket();
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    private void handleClientSocket() throws IOException, InterruptedException {
    	
    	System.out.println("Worker Reached");
    	
    	
    	//Set-up bi-directional communication with client
    	InputStream inputStream = clientSocket.getInputStream();
    	OutputStream outputStream = clientSocket.getOutputStream();
    	
    	BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
    	//String line;
    	//while( (line = reader.readLine()) != null) {
    	//	if("quit".equalsIgnoreCase(line)) {
    	//		break;
    	//	}
    	//	String msg = "You typed: " + line + "\n";
    	//	outputStream.write(msg.getBytes());
    	//}
    	int lobbyKey;
    	int amount = 0;
    	String amountString;
    	
    	//Send Clients Message of current commodity attributes
    	//outputStream.write((TestCommodity.getName() + "\n").getBytes());
    	//outputStream.write(("Price: " + TestCommodity.getPrice() + "\n").getBytes());
    	//outputStream.write(("Quantity Avaliable: " + TestCommodity.getQuantityAvaliable() + "\n").getBytes());
    	
    	outputStream.write(("Press 2 to create a lobby, Press 3 to join a lobby" + "\n").getBytes());
    	
    	while(amount != 1) {
    		amount = Integer.parseInt(reader.readLine());
    		//System.out.println("You entered: " + amount);
    		
    		if(amount == 2) {
    			outputStream.write(("Creating lobby.." + "\n").getBytes());
    			lobbyKey = ServerLobby.createLobby();
    			outputStream.write(("Your lobby has been created. Your code: " + lobbyKey + "\n").getBytes());
    			//Create a lobby timer
    		}
    		if(amount == 3) {
    			outputStream.write(("Enter lobby access code.." + "\n").getBytes());
    			ServerLobby.joinLobby();
    		}
    		
    		outputStream.write(ServerMain.gold.getQuantity());
    		ServerMain.anfan.buy(100,ServerMain.gold);
    		int temp2 = ServerMain.gold.getQuantity();
    		outputStream.write(("New quantity" + temp2 + "\n").getBytes());
    		
    		
    		
    		//ServerMain.commoditiesArray[0].setQuantityAvaliable(amount);
    		//int x = ServerMain.commoditiesArray[0].getQuantityAvaliable();
    		
    		//outputStream.write(("Enter lobby access code.."  + "\n").getBytes());
    		//Display Updates
    		//amountString = Integer.toString(amount);
    		//outputStream.write(("You entered: �" + amountString + "\n").getBytes());
    		
    		//TestCommodity.setQuantityAvaliable(amount);
    		
    	}
    	
    	
    	
    	
    	
    	
    	System.out.println("Connection closed");
    	//Close connection
    	clientSocket.close();
		
		
		
	}
	

}
