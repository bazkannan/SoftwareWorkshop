package Server;

/**
 * @author group3.Anfan
 */
public class Commodity {

    private String name;
    private int itemID;
    private double currentPrice;
    private int quantity;

    // Constructor for global Commodity
    public Commodity(String name, int itemID, double m, int quantity, int c){
        this.name = name;
        this.itemID = itemID;

        double price = c -(m * quantity);
        if (price > 0){
            this.currentPrice = price;
        } else {
            this.currentPrice = 0;
        }

        this.quantity = quantity;
        System.out.printf("Commodity %s created. Starting price %f, starting quantity %d%n",
                name, this.getCurrentPrice(), quantity);
    }

    // Constructor for Commodity, goes in the TradiningAccount's portfolio
    public Commodity(String name, int itemID, int quantity){
        this.name = name;
        this.itemID = itemID;
        this.quantity = quantity;
    }

    public int getItemID() {
        return itemID;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public void setCurrentPrice(double currentPrice) {
        this.currentPrice = currentPrice;
    }

    public String getName() {
        return name;
    }

    public double getCurrentPrice() {
        return currentPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCurrentPrice(int newPrice) {
        this.currentPrice = newPrice;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

//    public void eventHappens(RandomEvent event){
//        System.out.printf("Event %s has occurred! %n", event.getName());
//        System.out.printf("%s price was %f %n", this.getName(), this.currentPrice);
//
//        this.currentPrice = currentPrice * event.getPercentChange();
//
//        System.out.printf("%s price is now %f %n", this.getName(), this.currentPrice);
//
//    }

}
