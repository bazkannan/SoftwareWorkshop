package Server;

/**
 * @author group3.Anfan
 */
public class TradingAccount {

    private String name;
    private double money;
    private int hiscore;
    private Commodity[] portfolio;


    public TradingAccount(String name, int money){
        this.name = name;
        this.money = money;
        this.hiscore = 0;
        this.portfolio = new Commodity[20];
    }

    // A TradingAccount buying a Commodity object and placing in portfolio
    public void buy(int buyQuantity, Commodity commod){
    	
    	System.out.println(commod.getQuantity());

        String name = commod.getName();
        int id = commod.getItemID();
        double price = commod.getCurrentPrice();
        int currentQuantity = commod.getQuantity();

        if (buyQuantity * price < this.money && buyQuantity < currentQuantity){
            this.money = money - (buyQuantity * price);

            commod.setQuantity(commod.getQuantity() - buyQuantity);

            this.portfolio[id] = new Commodity(name, id, buyQuantity );
            
            System.out.println(commod.getQuantity());

            System.out.println(name + " was successfully bought.");

            // update global price??

        } else {
            System.out.println("Cannot buy, either quantity invalid or cash insufficient.");
        }

    }


    // A TradingAccount selling a Commodity object and placing in portfolio
    public void sell(int sellQuantity, Commodity commod){

        int ownedQuantity;
        String name = commod.getName();
        int id = commod.getItemID();
        double price = commod.getCurrentPrice();

        // check if you own this commodity in your portfolio
        if(portfolio[id] != null){
            ownedQuantity = portfolio[id].getQuantity();

        } else {
            System.out.println("You do not own any of this commodity.");
            return;
        }

        // check if quantity owned is sufficient
        if (ownedQuantity >= sellQuantity){
            portfolio[id].setQuantity(ownedQuantity - sellQuantity);
            this.money += sellQuantity * commod.getCurrentPrice();
            System.out.println(name + " was successfully sold.");

        } else {
            System.out.println("You do not have enough of this commodity.");
        }


    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int getHiscore() {
        return hiscore;
    }

    public void setHiscore(int hiscore) {
        this.hiscore = hiscore;
    }

    public Commodity[] getPortfolio() {
        return portfolio;
    }

    public void setPortfolio(Commodity[] portfolio) {
        this.portfolio = portfolio;
    }
}
