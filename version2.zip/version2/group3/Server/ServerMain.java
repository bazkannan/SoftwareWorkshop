package Server;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Class to create a Server. Uses the main thread to establish connections with client sockets
 * and uses other threads for communication.
 * @author Thomas Baker
 */
public class ServerMain {
	
	
	public static Commodity gold = new Commodity("Gold", 1, 0.005, 1000, 500);
    public static Commodity sugar = new Commodity("Sugar", 2, 0.009, 10000, 100);
    public static Commodity oil = new Commodity("Oil", 3, 0.05, 1000, 300);
    public static Commodity silver = new Commodity("Silver", 2, 0.009, 10000, 100);
    public static Commodity wheat = new Commodity("Wheat", 3, 0.05, 1000, 300);
    
    public static TradingAccount anfan = new TradingAccount("group3.Anfan Li", 1000000);
//    anfan.buy(10, gold);
//    anfan.buy(1000, gold);
	
	public static Commodity[] commoditiesArray = new Commodity[20];
	
	
	//public static GameSession[] 

	public static void main(String args[]) throws InterruptedException {
		
		int port = 8818;
		
		commoditiesArray[0] = gold;
		commoditiesArray[1] = sugar;
		commoditiesArray[2] = silver;
		commoditiesArray[3] = oil;
		commoditiesArray[4] = wheat;
		
		try {
			 
			//Create a server socket @param port number
			ServerSocket serverSocket = new ServerSocket(port);
			
			//Put in loop to maintain connection
			while(true) {
				
				System.out.println("Awaiting Connection");
				
				//Call accept method to create connection between server and client
				Socket clientSocket = serverSocket.accept();
				
				System.out.println("Connection established");
				
				//Instead of creating new thread, create new instance of server worker
				ServerThread clientThread = new ServerThread(clientSocket);
				clientThread.start();
				
				//Send message to client
				//outputStream.write("Hello World\n".getBytes());
				
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	
	
	

}
