package Server;

import java.util.Random;

/**
 * This class handles the service of lobbies. Both a client creating one and clients joining one
 * @author Thomas Baker
 * 
 */
public class ServerLobby {
	
	//Create list of available lobbies (move to live games when game begins)
	
	//Create list of live games (remove from list when game ends)
	
	public static int createLobby() {
		
		int lobbyKey;
		
		//Create random 6 digit lobby key
		Random rnd = new Random();
		lobbyKey = 100000 + rnd.nextInt(900000);
		System.out.println(lobbyKey);
		
		return lobbyKey;
	}
	
	public static void joinLobby() {
		
	}

}
