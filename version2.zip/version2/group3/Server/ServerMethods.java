package Server;

/**
 * A class containing a collection of methods used by the server to alter prices of commodities
 * @author Thomas Baker
 *
 */
public class ServerMethods {
	
	public static void changeGold(int quantity) {
		
	}

}
