package sample.group3.graphs;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

/**
 * Class to generate the graphs for the Stock Market. Uses JavaFX graphs
 * @Bharath Kannan
 */
public class Chart extends Application {

    @Override
    public void start (Stage stage) {
        stage.setTitle("Baker Stock Market");
        CategoryAxis xAxis = new CategoryAxis();
        // NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Timeline");
        yAxis.setLabel("Stocks");
        // xAxis.setSide(Side.TOP);
        LineChart<String, Number> lineChart = new LineChart<String, Number>(xAxis, yAxis);

        // LineChart<Number, Number> lineChart = new LineChart<Number, Number>(xAxis, yAxis);

        lineChart.setCreateSymbols(true);
        lineChart.setTitle("Baker Stock Market");
        XYChart.Series series1 = new XYChart.Series();
        series1.setName ("Sample Data 1");
        series1.getData().add(new XYChart.Data("Jan", 5));
        series1.getData().add(new XYChart.Data("Feb", 10));
        series1.getData().add(new XYChart.Data("Mar", 15));
        series1.getData().add(new XYChart.Data("Apr", 24));
        series1.getData().add(new XYChart.Data("May", 34));
        series1.getData().add(new XYChart.Data("Jun", 36));
        series1.getData().add(new XYChart.Data("Jul", 36));
        series1.getData().add(new XYChart.Data("Aug", 34));
        series1.getData().add(new XYChart.Data("Sep", 24));
        series1.getData().add(new XYChart.Data("Oct", 15));
        series1.getData().add(new XYChart.Data("Nov", 10));
        series1.getData().add(new XYChart.Data("Dec", 5));

        XYChart.Series series2 = new XYChart.Series();
        series2.setName ("Sample Data 2");
        series2.getData().add(new XYChart.Data("Jan", 20));
        series2.getData().add(new XYChart.Data("Feb", 25));
        series2.getData().add(new XYChart.Data("Mar", 43));
        series2.getData().add(new XYChart.Data("Apr", 21));
        series2.getData().add(new XYChart.Data("May", 53));
        series2.getData().add(new XYChart.Data("Jun", 75));
        series2.getData().add(new XYChart.Data("Jul", 35));
        series2.getData().add(new XYChart.Data("Aug", 23));
        series2.getData().add(new XYChart.Data("Sep", 27));
        series2.getData().add(new XYChart.Data("Oct", 35));
        series2.getData().add(new XYChart.Data("Nov", 63));
        series2.getData().add(new XYChart.Data("Dec", 19));

        XYChart.Series seriesMovingAverage1 = new XYChart.Series();
        seriesMovingAverage1.setName("Data 1 Moving Average");
        seriesMovingAverage1.getData().add(new XYChart.Data("Jan", 5));
        seriesMovingAverage1.getData().add(new XYChart.Data("Feb", (5 + 10)/2));
        seriesMovingAverage1.getData().add(new XYChart.Data("Mar", (5 + 10 + 15)/3));
        seriesMovingAverage1.getData().add(new XYChart.Data("Apr", (5 + 10 + 15 + 24)/4));
        seriesMovingAverage1.getData().add(new XYChart.Data("May", (5 + 10 + 15 + 24 + 34)/5));
        seriesMovingAverage1.getData().add(new XYChart.Data("Jun", (5 + 10 + 15 + 24 + 34 + 36)/6));
        seriesMovingAverage1.getData().add(new XYChart.Data("Jul", (5 + 10 + 15 + 24 + 34 + 36 + 36)/7));
        seriesMovingAverage1.getData().add(new XYChart.Data("Aug", (5 + 10 + 15 + 24 + 34 + 36 + 36 + 34)/8));
        seriesMovingAverage1.getData().add(new XYChart.Data("Sep", (5 + 10 + 15 + 24 + 34 + 36 + 36 + 34 + 24)/9));
        seriesMovingAverage1.getData().add(new XYChart.Data("Oct", (5 + 10 + 15 + 24 + 34 + 36 + 36 + 34 + 24 + 15)/10));
        seriesMovingAverage1.getData().add(new XYChart.Data("Nov", (5 + 10 + 15 + 24 + 34 + 36 + 36 + 34 + 24 + 15 + 10)/11));
        seriesMovingAverage1.getData().add(new XYChart.Data("Dec", (5 + 10 + 15 + 24 + 34 + 36 + 36 + 34 + 24 + 15 + 10 + 5)/12));

        XYChart.Series seriesMovingAverage2 = new XYChart.Series();
        seriesMovingAverage2.setName("Data 2 Moving Average");
        seriesMovingAverage2.getData().add(new XYChart.Data("Jan", 20));
        seriesMovingAverage2.getData().add(new XYChart.Data("Feb", (20 + 25)/2));
        seriesMovingAverage2.getData().add(new XYChart.Data("Mar", (20 + 25 + 43)/3));
        seriesMovingAverage2.getData().add(new XYChart.Data("Apr", (20 + 25 + 43 + 21)/4));
        seriesMovingAverage2.getData().add(new XYChart.Data("May", (20 + 25 + 43 + 21 + 53)/5));
        seriesMovingAverage2.getData().add(new XYChart.Data("Jun", (20 + 25 + 43 + 21 + 53 + 75)/6));
        seriesMovingAverage2.getData().add(new XYChart.Data("Jul", (20 + 25 + 43 + 21 + 53 + 75 + 35)/7));
        seriesMovingAverage2.getData().add(new XYChart.Data("Aug", (20 + 25 + 43 + 21 + 53 + 75 + 35 + 23)/8));
        seriesMovingAverage2.getData().add(new XYChart.Data("Sep", (20 + 25 + 43 + 21 + 53 + 75 + 35 + 23 + 27)/9));
        seriesMovingAverage2.getData().add(new XYChart.Data("Oct", (20 + 25 + 43 + 21 + 53 + 75 + 35 + 23 + 27 + 35)/10));
        seriesMovingAverage2.getData().add(new XYChart.Data("Nov", (20 + 25 + 43 + 21 + 53 + 75 + 35 + 23 + 27 + 35 + 63)/11));
        seriesMovingAverage2.getData().add(new XYChart.Data("Dec", (20 + 25 + 43 + 21 + 53 + 75 + 35 + 23 + 27 + 35 + 63 + 19)/12));

        public void bollinger (int bollinger) {

            List<Integer> list = new ArrayList<Integer>();
            list.add(20);
            list.add(25);
            list.add(43);
            list.add(21);
            list.add(53);
            list.add(75);
            list.add(35);
            list.add(23);
            list.add(27);
            list.add(35);
            list.add(63);
            list.add(19);

            int total = 12;

            for (int element : list) {
                int movingAverage = element / total;
                int difference = element - movingAverage;
            }

            int square = difference*difference;

            int sum = square / total;
            double x = Math.sqrt(sum);
        }

        /* Calculate the simple moving average:

25.5 + 26.75 + 27.0 + 26.5 + 27.25 = 133.0
133.0 / 5 = 26.6

Next, for each bar, subtract 26.6 from the close and square this value:

25.5 - 26.6 =	-1.1	squared =	1.21
26.75 - 26.6 =	0.15	squared =	0.023
27.0 - 26.6 =	0.4	squared =	0.16
26.5 - 26.6 =	0.1	squared =	0.01
27.25 - 26.6 =	0.65	squared =	0.423

Add the above calculated values, divide by 5, and then get the square root of this value to get the deviation value:

1.21 + 0.023 + 0.16 + 0.01 + 0.423 = 1.826
 1.826 / 5 = 0.365
Square root of .365 = 0.604

The upper Bollinger band would be 26.6 + (2 * 0.604) = 27.808

The middle Bollinger band would be 26.6

The lower Bollinger band would be 26.6 - (2 * 0.604) = 25.392 */


        Scene scene = new Scene(lineChart, 800, 600);
        // lineChart.getData().add(series1);
        // lineChart.getData().addAll(series1, series2, seriesMovingAverage1, seriesMovingAverage2);
        lineChart.getData().addAll(series2, seriesMovingAverage2);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String [] args) {
        launch(args);
    }
}
