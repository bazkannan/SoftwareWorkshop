package sample.group3.login;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

/**
 * Class to generate the GUI for the login screen.
 * @author Bharath Kannan
 */
public class Login extends Application {

    @Override
    public void start(Stage primaryStage) {

        primaryStage.setTitle("Stock Market Game");

        GridPane grid = new GridPane();
        grid.setGridLinesVisible(false);
        grid.setVisible(true);
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(0);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Text sceneTitle = new Text("   Stock Market Login");
        sceneTitle.setTextAlignment(TextAlignment.CENTER);
        sceneTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        sceneTitle.setStroke(Color.WHITE);
        sceneTitle.setStrokeWidth(0.5);
        grid.add(sceneTitle, 0, 0, 2, 1);

        Label userName = new Label ("User ID: ");
        userName.setAlignment(Pos.CENTER_RIGHT);
        userName.setTextAlignment(TextAlignment.RIGHT);
        userName.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        userName.setStyle("-fx-font-weight: bold");
        grid.add(userName, 0, 1);

        TextField userTextField = new TextField();
        grid.add(userTextField, 1, 1);

        Label password = new Label ("Password: ");
        password.setTextAlignment(TextAlignment.CENTER);
        password.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        password.setAlignment(Pos.CENTER_LEFT);
        password.setStyle("-fx-font-weight: bold");
        grid.add(password, 0, 2);

        PasswordField passwordBox = new PasswordField();
        grid.add(passwordBox, 1, 2);
        grid.setGridLinesVisible(false);

        Button button1 = new Button("Sign Up");
        HBox hbButton1 = new HBox(10);
        button1.setAlignment(Pos.CENTER_RIGHT);
        hbButton1.setAlignment(Pos.CENTER_RIGHT);
        hbButton1.getChildren().add(button1);
        grid.add(hbButton1, 1, 3);

        Button button2 = new Button("  Login  ");
        HBox hbButton2 = new HBox(10);
        button2.setAlignment(Pos.CENTER_LEFT);
        hbButton2.setAlignment(Pos.CENTER_LEFT);
        hbButton2.getChildren().add(button2);
        grid.add(hbButton2, 1, 3);

        Label trademark = new Label ("© 2019 Baker Stock Market - All Rights Reserved");
        trademark.setTextAlignment(TextAlignment.RIGHT);
        trademark.setFont(Font.font("Arial", FontWeight.NORMAL, 5));
        trademark.setAlignment(Pos.BOTTOM_RIGHT);
        grid.add(trademark, 1, 9);

        Text actionTarget = new Text();
        grid.add(actionTarget, 1, 6);

        Text actionTarget2 = new Text();
        grid.add(actionTarget2, 1, 6);

        button2.setOnAction(new EventHandler<ActionEvent>() {

            public void handle (ActionEvent e) {
                actionTarget2.setFill(Color.FIREBRICK);
                actionTarget2.setText("Login Button Pressed");
                actionTarget2.setTextAlignment(TextAlignment.CENTER);
            }
        });

        button1.setOnAction(new EventHandler<ActionEvent>() {

            public void handle (ActionEvent e) {
                actionTarget.setFill(Color.FIREBRICK);
                actionTarget.setText("Account created");
                actionTarget.setTextAlignment(TextAlignment.CENTER);

                // if account is not found and button is pressed, display error message
                // else if account is found and login button pressed, sign in
                // if sign up button is pressed, add details to the class

            }

            public void actionPerformed (ActionEvent e) {

                String username = txtUsername.getText();
                String password = txtPassword.getText();

                if (password.contains("rocky") && username.contains("baz")) {
                    txtUsername.setText(null);
                    txtPassword.setText(null);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid login details", "Login Error", JOptionPane.ERROR);
                    txtUsername.setText(null);
                    txtPassword.setText(null);
                }
            }
        });

        Scene scene = new Scene(grid, 300, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }

}
