package sample;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class MainScreen extends Application {

    public static String login_signup = "main";
    public static String loginSignupFxml = "login_signup.fxml";
    public static String screenPreLobbyFXML = "preLobby.fxml";
    public static String screenPreLobby = "preLobby2";
    public static String screen2ID = "screen2";
    public static String screen2File = "Screen2.fxml";
    public static String screen3ID = "screen3";
    public static String screen3File = "Screen3.fxml";


    @Override
    public void start(Stage primaryStage) {

        ScreenMapping mainContainer = new ScreenMapping();
        mainContainer.loadScreen(MainScreen.login_signup, MainScreen.loginSignupFxml);
        mainContainer.loadScreen(MainScreen.screenPreLobby, MainScreen.screenPreLobbyFXML);
        mainContainer.loadScreen(MainScreen.screen2ID, MainScreen.screen2File);
        mainContainer.loadScreen(MainScreen.screen3ID, MainScreen.screen3File);

        mainContainer.setScreen(MainScreen.login_signup);

        Group root = new Group();
        root.getChildren().addAll(mainContainer);
        Scene scene = new Scene(root);
        primaryStage.setTitle("Stock Market Challenge");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}

