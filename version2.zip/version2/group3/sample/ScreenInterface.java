package sample;

public interface ScreenInterface {

    //This method will allow the introduction of the Parent ScreenPane
    void setScreenParent(ScreenMapping screenPage);
}
