package sample;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import sample.ScreenInterface;
import sample.ScreenMapping;

/**
 * FXML Controller class
 *
 * @author Angie
 */
public class ScreenController3 implements Initializable, ScreenInterface {

    ScreenMapping myController;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void setScreenParent(ScreenMapping screenParent){
        myController = screenParent;
    }

    @FXML
    LineChart<String, Number> lineChart;

    public void btn(ActionEvent event) {

        XYChart.Series <String, Number> series1 = new XYChart.Series<>();
        series1.setName ("Sample Data 1");
        series1.getData().add(new XYChart.Data<>("Jan", 5));
        series1.getData().add(new XYChart.Data("Feb", 10));
        series1.getData().add(new XYChart.Data("Mar", 15));
        series1.getData().add(new XYChart.Data("Apr", 24));
        series1.getData().add(new XYChart.Data("May", 34));
        series1.getData().add(new XYChart.Data("Jun", 36));
        series1.getData().add(new XYChart.Data("Jul", 36));
        series1.getData().add(new XYChart.Data("Aug", 34));
        series1.getData().add(new XYChart.Data("Sep", 24));
        series1.getData().add(new XYChart.Data("Oct", 15));
        series1.getData().add(new XYChart.Data("Nov", 10));
        series1.getData().add(new XYChart.Data("Dec", 5));
        lineChart.getData().add(series1);
    }

    public void btn2(ActionEvent event) {

        XYChart.Series <String, Number> series2 = new XYChart.Series<>();
        series2.setName ("Sample Data 2");
        series2.getData().add(new XYChart.Data("Jan", 20));
        series2.getData().add(new XYChart.Data("Feb", 25));
        series2.getData().add(new XYChart.Data("Mar", 43));
        series2.getData().add(new XYChart.Data("Apr", 21));
        series2.getData().add(new XYChart.Data("May", 53));
        series2.getData().add(new XYChart.Data("Jun", 75));
        series2.getData().add(new XYChart.Data("Jul", 35));
        series2.getData().add(new XYChart.Data("Aug", 23));
        series2.getData().add(new XYChart.Data("Sep", 27));
        series2.getData().add(new XYChart.Data("Oct", 35));
        series2.getData().add(new XYChart.Data("Nov", 63));
        series2.getData().add(new XYChart.Data("Dec", 19));
        lineChart.getData().add(series2);
    }
}
