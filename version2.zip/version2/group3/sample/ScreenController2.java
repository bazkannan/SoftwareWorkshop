package sample;

import java.net.URL;
import java.util.ResourceBundle;

import com.sun.javafx.application.LauncherImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ProgressBar;


public class ScreenController2 implements Initializable , ScreenInterface {

    ScreenMapping myController;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void setScreenParent(ScreenMapping screenParent){
        myController = screenParent;
    }

    @FXML
    private void goToScreen3(ActionEvent event){
        myController.setScreen(MainScreen.screen3ID);
    }
    @FXML
    private ProgressBar progressBar;

    class bg_Thread implements Runnable {

        @Override
        public void run() {

            for (int i = 0; i < 100; i++) {

                progressBar.setProgress(i/100.0);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {

        Thread th = new Thread(new bg_Thread());
        th.start();

    }
//    public static void main(String[] args) {
//        LauncherImpl.launchApplication(ScreenController2.class, MyPreloader.class, args);
    }



