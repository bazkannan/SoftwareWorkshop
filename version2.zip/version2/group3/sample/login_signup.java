package sample;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import static javafx.application.Application.launch;


public class login_signup implements Initializable, ScreenInterface {

    ScreenMapping myController;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void setScreenParent(ScreenMapping screenParent) {
        myController = screenParent;
    }

    @FXML
    private void goToScreen2(ActionEvent event) {
        myController.setScreen(MainScreen.screen2ID);
    }

    @FXML
    private void goToPreLobby(ActionEvent event) {
        myController.setScreen(MainScreen.screenPreLobby);
    }

    @FXML
    private ImageView imageView;

    @FXML
    private void imageView() {
        Image image = new Image ("\"C:\\\\Users\\\\info\\\\OneDrive\\\\UoB\\\\Software Workshop II\\\\StockMarket2\\\\src\\\\sample\\\\Stock market.jpg");
        imageView();
    }

    public void start(Stage primaryStage) {

        primaryStage.setTitle("Baker Stock Market");

        GridPane grid = new GridPane();
        grid.setGridLinesVisible(true);
        grid.setVisible(true);
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(0);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Text sceneTitle = new Text("   Stock Market LoginSc1");
        sceneTitle.setTextAlignment(TextAlignment.CENTER);
        sceneTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        sceneTitle.setStroke(Color.WHITE);
        sceneTitle.setStrokeWidth(0.5);
        grid.add(sceneTitle, 0, 0, 2, 1);

        Label userName = new Label("User ID: ");
        userName.setAlignment(Pos.CENTER_RIGHT);
        userName.setTextAlignment(TextAlignment.RIGHT);
        userName.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        userName.setStyle("-fx-font-weight: bold");
        grid.add(userName, 0, 1);

        TextField userTextField = new TextField();
        grid.add(userTextField, 1, 1);

        Label password = new Label("Password: ");
        password.setTextAlignment(TextAlignment.CENTER);
        password.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        password.setAlignment(Pos.CENTER_LEFT);
        password.setStyle("-fx-font-weight: bold");
        grid.add(password, 0, 2);

        PasswordField passwordBox = new PasswordField();
        grid.add(passwordBox, 1, 2);
        grid.setGridLinesVisible(false);

        Button button = new Button("LoginSc1");
        HBox hbButton = new HBox(10);
        button.setAlignment(Pos.CENTER);
        hbButton.setAlignment(Pos.CENTER);
        hbButton.getChildren().add(button);
        grid.add(hbButton, 1, 3);

        Label trademark = new Label("© 2019 Baker Stock Market - All Rights Reserved");
        trademark.setTextAlignment(TextAlignment.RIGHT);
        trademark.setFont(Font.font("Arial", FontWeight.NORMAL, 5));
        trademark.setAlignment(Pos.BOTTOM_RIGHT);
        grid.add(trademark, 1, 9);

        final Text actionTarget = new Text();
        grid.add(actionTarget, 1, 6);

        button.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                actionTarget.setFill(Color.FIREBRICK);
                actionTarget.setText("LoginSc1 Button Pressed");
                actionTarget.setTextAlignment(TextAlignment.CENTER);

            }
        });

        Scene scene = new Scene(grid, 300, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}

