
public class Ex4a {
	/**
	 * In this worksheet, you can see my solutions to the problem the original code has which was that the code would not run and the variables as a result, would not be swapped. Please find below my comments and the method I have used to overcome this problem. 
	 * @author - Bharath Kannan
	 * @date 06 Oct 2018
	 * 
	 * swaps i and j. 
	 * @param i 1st variable. 
	 * @param j 2nd variable.
	 */

	public static void main(String[] args) {
			
			int i=6; 
			int j=4; 
			int temp; // For i to equal 6, we need to assign a temporary variable
			
			temp = i; // temp would equal 6 
			i=j; // i = 4
			j=temp; // j = 4 before the temp variable was introduced. After bringing in the temp variable, j = 6
			
			// Before swapping the variables
			
			System.out.println("Before: i = " + i + "\tj = " +j);
			
			/* Here we are swapping the variables using a temp variable. Although the main problem with using a temp variable is that it wastes a lot of memory space even though it does effectively solve the problem of using swap method */
		
			
			// Therefore this is after swapping the variables
			
			System.out.println("After: i = " + i + "\tj = " + j);
			System.out.println("Congratulations! You have successfully swapped the variables!");
		}
	
		
}


	
