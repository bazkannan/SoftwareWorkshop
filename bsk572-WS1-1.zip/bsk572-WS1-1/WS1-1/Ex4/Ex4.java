
public class Ex4 {
	/**
	 * In this worksheet, you can see my solutions to the problem the original code has which was that the code would not run and the variables as a result, would not be swapped. Please find below my comments and the method I have used to overcome this problem. 
	 * @author - Bharath Kannan
	 * @date 06 Oct 2018
	 * 
	 * swaps i and j. 
	 * @param i 1st variable. 
	 * @param j 2nd variable.
	 */

	public static void main(String[] args) {
			
			int i=6; 
			int j=4; 
			int temp; // For i to equal 6, we need to assign a temporary variable
			
			temp = i; // temp would equal 6 
			i=j; // i = 4
			j=temp; // j = 4 before the temp variable was introduced. After bringing in the temp variable, j = 6
			
			// Before swapping the variables
			
			System.out.println("Before: i = " + i + "\tj = " +j);
			
			/* Here we are swapping the variables using a temp variable. Although the main problem with using a temp variable is that it wastes a lot of memory space even though it does effectively solve the problem of using swap method */
		
			
			// Therefore this is after swapping the variables
			
			System.out.println("After: i = " + i + "\tj = " + j);
			System.out.println("Congratulations! You have successfully swapped the variables!");
		
		
			int l = 2; // Substituting i for l for the second problem as i is already defined in the first problem. 
		int k = 6; 
		System.out.println("Original l: " + l + " \nOriginal k: " + k);
		
		l = l + k; 
		k = l - k; 
		l = l - k;
		
		/* Instead of using swap(l, k); we will use something else instead. List out the l = l + k and so on. So no need for temp variable as when we run this code, uses less binary data. */
		System.out.println("New l: " + l + " \nNew k: " + k); 
		System.out.println("Congratulations! Your variables have been successfully swapped!");

	}
	
		
}


	
