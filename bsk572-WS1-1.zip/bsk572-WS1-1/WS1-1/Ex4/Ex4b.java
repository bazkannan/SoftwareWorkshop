/**
 * This is the second problem that I will be debugging to ensure that the variables have successfully swapped. 
 * @author Bharath
 * @date 6 Oct 2018
 */
public class Ex4b {

	public static void main(String[] args) {
		
		int i = 2; 
		int k = 6; 
		System.out.println("Original i: " + i + " \nOriginal k: " + k);
		
		i = i + k; 
		k = i - k; 
		i = i - k;
		
		/* Instead of using swap(i, k); we will use something else instead. List out the i = i + k and so on. So no need for temp variable as when we run this code, uses less binary data. */
		System.out.println("New i: " + i + " \nNew k: " + k); 
		System.out.println("Congratulations! Your variables have been successfully swapped!");

	}

}
