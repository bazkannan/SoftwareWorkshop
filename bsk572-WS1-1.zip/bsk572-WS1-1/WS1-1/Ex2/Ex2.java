/**
 * This exercise I will try to write a program that will convert the masses given in the imperial system to the metric system
 * @Bharath Kannan
 * @4 Oct 2018
 */


public class Ex2 {

public static double imperialToKg (double tonRaw, double hundredweightRaw, double quarterRaw, double stoneRaw, double ounceRaw, double drachmRaw, double grainRaw, double poundRaw) {

	
	double tonC, hundredweightC, quarterC, stoneC, ounceC, drachmC, grainC, poundC; 
	double pound, totalkg; 
	
	pound = 0.45359237; // This is the weight in kg
	
	

    tonC = 2240*tonRaw; // These values are in pounds and converting it by multiplying the pound value with the Raw value to get the converted value. 
    hundredweightC = 112*hundredweightRaw;
    quarterC = 28*quarterRaw;
    stoneC = 14*stoneRaw;
    ounceC = 0.0625*ounceRaw;
    drachmC = 0.00390625*drachmRaw;
    grainC = 0.0001428571429*grainRaw;
    poundC = poundRaw;
    
    totalkg = pound * (tonC + hundredweightC + quarterC + stoneC + ounceC + drachmC + grainC + poundC);
    /* Then we multiply the pound by the converted values to get the total weight in kg */ 
	return totalkg; 

}



	public static void main(String[] args) {
		
		  /* We are converting Imperial to KG. We multiply the pound units by kg to get the final answer in KG */

        /*
        We have to initialise the pound and the kg weight variables.

         */

        double pound;
        double kg;

        /* The units are multiplied by the pound to get the KG value */

        double ton;
        double hundredweight;
        double quarter;
        double stone;
        double ounce;
        double drachm;
        double grain; 
        double result; 
        
        /* declaring the variables for the different conversion values, then we assign null values to the variables that are not required for the conversion asked in the question */ 
        
        ton = 0; 
        hundredweight = 0; 
        quarter = 0; 
        stone = 11; 
        ounce = 0; 
        drachm = 0; 
        grain = 0; 
        pound = 6; 
        
        result = imperialToKg(ton, hundredweight, quarter, stone, ounce, drachm, grain, pound);
        System.out.println("Your weight in kg is " + result + "kg");
        
       

        /* For the second part, I have declared the values of stone and pound which we can input into our result equation */
		
		
	}

      
	}

    








   

    