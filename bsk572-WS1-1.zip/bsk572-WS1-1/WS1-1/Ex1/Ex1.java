/**
 * This project file will contain the solutions to the questions on the Worksheet one for the Software workshop module
 * @author Bharath Kannan
 * @4 Oct 2018
 */

import java.util.Scanner; 

public class Ex1 {
	
	public static double areaCircle(double radius) {
		
		double areaCircle;
		
		return areaCircle = Math.PI*radius*radius; 
		
	}

	public static void main(String[] args) {
		
		 /* According to the Mathematical theory, to calculate the Area of a circle. We use the formula PI * r-squared */


        /* Create a scanner to obtain input */

        Scanner input = new Scanner(System.in);

        double radius1; // We will input a number which would be the radius in our equation and is an integer
        double areaCircle; // Calculate Area of circle


        System.out.print("Input the following numbers as the value of the radius \n 0 \n 5 \n 10 \n to calculate the Area of a circle: ");
        radius1 = input.nextDouble(); // This reads the first number from the user and \n means new line so the user can see which numbers to input


        /* areaCircle = Math.PI*radius*radius */


        areaCircle = Math.PI * radius1 * radius1;
        /* Here we use the mathematical equation to calculate the Area which is PI multiplied by r squared */

        System.out.printf("Your answer is %f%n ", areaCircle);
        
        /* Here I am going to display both scenarios where we use the Scanner input to type a number that will work out the Area of a Circle and a function which will print out the Area with radius 0, 5 and 10 */


        System.out.printf("\nCORRECT ANSWER: Area of a circle with radius 0 is: ", areaCircle(0));
        System.out.println(areaCircle(0));
        System.out.printf("CORRECT ANSWER: Area of a circle with radius 5 is: ", areaCircle(5));
        System.out.println(areaCircle(5));
        System.out.printf("CORRECT ANSWER: Area of a circle with radius 10 is: ", areaCircle(10));
        System.out.println(areaCircle(10));

        /* Here we print out the answer to the console, we use the f for floating numbers in order for this to work */
		

	}

}



   

