/**
 * In this question, we are going to calculate the angle between the hour hand and minute hand of the clock
 * @Bharath Kannan
 * @4 Oct 2018
 */
import java.util.Scanner; 

public class Ex3 {
		
		public static void main(String[] args) {

	        // Initialising and declaring the hours, minutes and seconds of the clock
	        int minutes = 5; 
	        int hours = 3; 
	        double seconds = 0; 
	        int result; 
	        
	        /* I have put in the Scanner to type out the numbers for the following times to test to see if they work. So in this case it's 9:00, 3:00, 18:00, 1:00, 2:30 and 4:41 */
	        
	        Scanner input = new Scanner(System.in);
	        
	        System.out.printf("Input the minutes: \n");
	        minutes = input.nextInt(); 
	        
	        System.out.printf("Input the hours: \n");
	        hours = input.nextInt(); 
	        
	        System.out.printf("Input the seconds. Test for the following times 0:00:20 and 13:05:27.272727272727 \n");
	        seconds = input.nextDouble();
	        
	        System.out.println("The time is " + hours + " hours, " + minutes + " minutes and " + seconds + " seconds.");
	        
	        System.out.println(hours + ":" + minutes + ":" + seconds);
	      
	        result = timeToAngle(hours, minutes, seconds); 
	        System.out.println("The time in degrees: " + result);
	        
	        /* We put in the angle and work out the time to angle using the hours and minutes */
	        

	        /* hours take the values from 0 to 24 */

	        /* minutes take the values from 0 to 60 */

	        /* We know that the coding for this is correct as when we adjust the hours and minutes variables to the respective times, we get the correct angles */


	        /* Angles at 3:00 and 9:00 are 90 and 270 respectively */

	        /* 1 minute is 6, 1 hour is 30. Start from 12 o clock which is 0 degrees. No loops and conditionals */

	       

	    }
		
		
public static int timeToAngle(int hours, double minutes, double seconds) {
	
	int hourAngle = ((360/12)*hours);
	
	 /* Now we need to create a method to calculate the difference between the hours and minutes */
	
	/* 360 degrees in total. 12 hours in a day. 60 minutes in an hour */
	
	/* Then we subtract the minuteAngle from the hourAngle and add 360 degrees then add the remainder paramter % */
	
	int finalResult; 
	double minuteAngle = ((360/60)*minutes + 0.1*seconds);
	double secondAngle = ((360/3600)*seconds);
	double result = (hourAngle - minuteAngle + 360) %360;
	double degreesAdd = ((6*minutes+0.1*seconds) / 12); 
	
	/* 12 is the amount of hours in total. 0.1 degrees is multiplied by the seconds. 3600 seconds in an hour */
			
			/* 6 degrees in a minute, 30 degrees in an hour and we start from 12 o clock */
	
	finalResult = (int)Math.round((result + degreesAdd) %360);
	
	/* We use the Math.round operator to round to the nearest integer and we mod the 360 so that for certain times we display 0 instead of the 360 angle */
	        
	     return finalResult; 

	}
		

}



    


 