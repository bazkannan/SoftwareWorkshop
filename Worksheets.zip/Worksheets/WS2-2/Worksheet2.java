/**
 *@author Bharath Kannan 
 *This class contains the solution for Worksheet2
 */

public class Worksheet2 implements Worksheet2Interface {

	// Exercise 1
/**
 * Negating the tree by inversing the values of a by placing a negative sign. Negate all the values in the 
 * left and right branches. 
 * @param a
 * @return
 */
	static Tree<Integer> negateAll(Tree<Integer> a) {
		
		if (a.isEmpty()) {
			return a;
		} else {
		return new Tree<Integer>(-a.getValue(), negateAll(a.getLeft()), negateAll(a.getRight()));
		}
	}

	// Exercise 2
/**
 * Checking to see if all the values in the nodes are positive, returning true if it is the case. 
 * @param a
 * @return
 */
	static boolean allPositive(Tree<Integer> a) {
		if (a.isEmpty()) {
			return true;
		} else if (a.getValue() >= 0) {
			return allPositive(a.getLeft()) && allPositive(a.getRight());
		} else {
		return false;
	}
}

	// Exercise 3
/**
 * Recursively going through the levels of the tree. 
 * @param a
 * @param x
 * @return
 */
	static int level(Tree<Integer> a, int x) {
		if (a.isEmpty()) { // Check if it's more than one level
			return 0;
		} else if (a.getValue() == x) {
			return 1;
		} else if (level(a.getLeft(), x) != x) {
			return 1 + level(a.getLeft(), x); // return the level of a given node value. Going down one then back up the levels. 
		} else if (level(a.getRight(), x) != x) {
			return 1 + level(a.getRight(), x);
		} else {
		return 0;
		}
	} 

	// Exercise 4
	
/**
 * Helper method for append
 * @param L
 * @param M
 * @return
 */
	static <E> List<E> append(List<E> L, List<E> M) {
		if (L.isEmpty())
			return M;
		else
			return new List<>(L.getHead(), append(L.getTail(), M));
	}
/**
 * Helper method for addtoend
 * @param L
 * @param i
 * @return
 */
	static <E> List<E> addtoend(List<E> L, E i) {
		return append(L, new List<>(i, new List<>()));
	}
	
/**
 * The method for post order traversal, if the tree is empty we return an empty list and we use
 * two helper functions add to end and append. 
 * @param a
 * @return
 */
	static <E> List<E> postorder(Tree<E> a) {
		if (a.isEmpty()) {
			return new List<E>();
		} else {
			return addtoend(append(postorder(a.getLeft()), postorder(a.getRight())), a.getValue());
		}
	}

	// Exercise 5
	
	// Do helper methods for minimum and maximum
/**
 * Helper method for search tree
 * @param a
 * @return
 */
	static boolean isSearchTree(Tree<Integer> a) {
		return isSearchTree(a, Integer.MIN_VALUE, Integer.MAX_VALUE);
	}
	
/**
 * Including the minimum and maximum helper functions for the search tree method. Do this for both the left and right
 * hand side. 
 * @param a
 * @param maximum
 * @param minimum
 * @return
 */
	static boolean isSearchTree(Tree<Integer> a, int maximum, int minimum) {
		if (a.isEmpty()) {
			return true;
		} if (a.getValue() <= maximum || a.getValue() >= minimum) {
			return false;
		} else {
			return isSearchTree(a.getLeft(), a.getValue(), minimum) && isSearchTree(a.getRight(), a.getValue(), maximum);
		}
	}

	// Exercise 6
/**
 * Printing the value in the trees to the console. We also call out the print descending method recursively
 * for the left and right.
 * @param a
 */
	static void printDescending(Tree<Integer> a) {
		if (a.isEmpty()) {
			return;
		} else {
			printDescending(a.getRight());
			System.out.println(a.getValue());
			printDescending(a.getLeft());;
		}
	}

	// Exercise 7
/**
 * Getting the maximum value from the tree. 
 * @param a
 * @return
 */
	static int max(Tree<Integer> a) {
		if (a.isEmpty()) {
			throw new IllegalStateException();
		} else if (a.getRight().isEmpty()) {
			return a.getValue();
		} else {
			return max(a.getRight());
		}
	}


	// Exercise 8
	
	
/**
 * Delete the value x from a and return the resultant tree. 
 * Don't alter the original tree but build a new tree that contains
 * all the values of a except for one copy of x. Must be BST.
 * Replacing x in the node with maximum value of left tree. 
 * @param a
 * @param x
 * @return
 */
	static Tree<Integer> delete(Tree<Integer> a, int x) {
		if (a.isEmpty()) {
			return new Tree<Integer>();
		} 
		else if (x > a.getValue()) {
			return new Tree<Integer>(a.getValue(), a.getLeft(), delete(a.getRight(), x)); 
		}
		else if (x < a.getValue()) {
			return new Tree<Integer>(a.getValue(), delete(a.getLeft(), x),a.getRight());
		} 
		else if (a.getLeft().isEmpty() && a.getRight().isEmpty()) {
			return new Tree<Integer>();
		}
		else if (a.getLeft().isEmpty()) {
			return a.getRight();
		}
		else if (a.getRight().isEmpty()) {
			return a.getLeft();
		} 
		else {
			return new Tree<Integer> (max(a.getLeft()), delete(a.getLeft(), max(a.getLeft())), a.getRight());
		} // header, left and right 
	}



	// Exercise 9
/**
 * Checking to see if the height on the trees for left and right hand side are balanced. 
 * If less than or equal to 1, we return true. 
 * @param a
 * @return
 */
	static <E> boolean isHeightBalanced(Tree<E> a) {
		if (a.isEmpty()) {
			return true;
		} else if (Math.abs((a.getLeft().getHeight() - a.getRight().getHeight())) <= 1) {
			return true;
		} else {
		return false;
	}
}

	// Exercise 10
/**
 * NULL
 * @param a
 * @param x
 * @return
 */
	static Tree<Integer> insertHB(Tree<Integer> a, int x) {
		return new Tree<Integer>();
	}
/**
 * NULL
 * @param a
 * @param x
 * @return
 */
	static Tree<Integer> deleteHB(Tree<Integer> a, int x) {
		return new Tree<Integer>();
	}
	
/**
 * Main method to test solutions for questions
 * @param args
 */
	public static void main (String [] args) {
	
		Tree<Integer> a = new Tree<>(2, new Tree<>(5), new Tree<>(1));
      	System.out.println("Exercise 1 Original: " + a);
      	System.out.println("Exercise 1 Answer: " + negateAll(a));
      	
      	Tree<Integer> b= new Tree<>(2, new Tree<>(5), new Tree<>(1));
      	Tree<Integer> a21 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
      	System.out.println("Exercise 2 Before: " + b);
        System.out.println("Exercise 2 Answer: " + allPositive(b));
        System.out.println("Exercise 2 Answer: " + allPositive(a21));
        
        Tree<Integer> c = new Tree<>(2, new Tree<>(5), new Tree<>(1));
        System.out.println("Exercise 3 Before: " + c);
        System.out.println("Exercise 3 Answer: " + level(c, 2));
       
        Tree<Integer> d = new Tree<>(2, new Tree<>(5), new Tree<>(1));
        System.out.println("Exercise 4 Before: " + d);
        System.out.println("Exercise 4 Answer: " + postorder(d));
        
        Tree<Integer> e = new Tree<>(2, new Tree<>(5), new Tree<>(1));
        Tree<Integer> a51 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	    System.out.println("Exercise 5 Answer for a51: " + isSearchTree(a51));
        System.out.println("Exercise 5 Before: " + e);
        System.out.println("Exercise 5 Answer: " + isSearchTree(e));
        
        Tree<Integer> g = new Tree<>(2, new Tree<>(5), new Tree<>(1));
        System.out.println("Exercise 7 Before: " + g);
        System.out.println("Exercise 7 Answer: " + max(g));
        
        Tree<Integer> h = new Tree<>(2, new Tree<>(5), new Tree<>(1));
        System.out.println("Exercise 8 Before: " + h);
        System.out.println("Exercise 8 Answer: " + delete(h, 2));
        
        Tree<Integer> i = new Tree<>(2, new Tree<>(5), new Tree<>(1));
        Tree <Integer> a91 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
        System.out.println("Exercise 9 Before: " + i);
        System.out.println("Exercise 9 Before: " + a91);
        System.out.println("Exercise 9 Answer: " + isHeightBalanced(i));
        System.out.println("Exercise 9 Answer: " + isHeightBalanced(a91)); 
		
	}

}

