package predictive;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.io.*;
import java.lang.System;
import java.nio.file.Paths;

/**
 * This class contains the solutions for the Worksheet 3, question 1. 
 * @author Bharath
 *
 */
public class PredictivePrototype {
	
	/**
	 * Method to change the words to signature. 
	 * @param words
	 * @return words.toString()
	 */
	@SuppressWarnings("unlikely-arg-type")
	public static String wordToSignature(String word) {
		
		StringBuffer words = new StringBuffer();
		
		// Looping through the words in the predictive text
		for (int i = 0; i < words.length(); i++) {
			
			if ((words.equals("a")) || words.equals("b") || words.equals("c")) {
				words.append(2);
			} else if ((words.equals("d")) || words.equals("e") || words.equals("f")) {
				words.append(3);
			} else if ((words.equals("g")) || words.equals("h") || words.equals("i")) {
				words.append(4);
			} else if ((words.equals("j")) || words.equals("k") || words.equals("l")) {
				words.append(5);
			} else if ((words.equals("m")) || words.equals("n") || words.equals("o")) {
				words.append(6);
			} else if ((words.equals("p")) || words.equals("q") || words.equals("r") || words.equals("s")) {
				words.append(7);
			} else if ((words.equals("t")) || words.equals("u") || words.equals("v")) {
				words.append(8);
			} else if ((words.equals("w")) || words.equals("x") || words.equals("y") || words.equals("z")) {
				words.append(9);
			} else {
				words.append("");
			}
		} 
		return words.toString();
}
			
		/*	String type = " ";
			
			switch(type) {
			
			case "a" :
			case "b" :
			case "c" :
				words.append(2);
				break; 
			
			case "d" : 
			case "e" :
			case "f" :
				words.append(3);
				break;
			
			case "g" :
			case "h" :
			case "i" :
				words.append(4);
				break;
				
			case "j" :
			case "k" :
			case "l" :
				words.append(5);
				break;
				
			case "m" :
			case "n" :
			case "o" :
				words.append(6);
				break;
				
			case "p" :
			case "q" :
			case "r" :
			case "s" :
				words.append(7);
				break;
				
			case "t" :
			case "u" :
			case "v" :
				words.append(8);
				break;
				
			case "w" :
			case "x" :
			case "y" :
			case "z" :
				words.append(9);
				
			default : 
				words.append(" ");
			}
		}
		return words.toString(); 
	} */
	
	/**
	 * Helper method which contains an enhanced for loop. Looping through
	 * the array of characters. If the character is a letter, return true 
	 * otherwise return false. 
	 * @param word
	 * @return
	 * 
	 */
	static boolean isValidWord(String word) {
		for (char c : word.toCharArray()) {
			if (Character.isLetter(c)) {
				return true;
			} 
	} return false;
}
	
	/**
	 * Why the implementation of storing the dictionary in your java program is inefficient. 
	 * Takes up unnecessary power, want to store less information in the JVM.  
	 * @param signature
	 * @return
	 */
	public static Set<String> signatureToWords(String signature) {
		
		Set<String> set = new HashSet<String>();
		
		try {
		Scanner input = new Scanner(Paths.get("src/preditive/words"));
		
		while(input.hasNext()) {
			String nextWord = input.nextLine().toLowerCase();
			String returnedString = wordToSignature(nextWord);
			if (isValidWord(nextWord) && returnedString.equals(signature)) {
				set.add(nextWord);
			}
		}
		input.close(); // Closing the scanner so that it's not taking up memory for JVM 
	} catch (IOException e) {
		System.out.println("Not found");
	} return set;
}

	/**
	 * Main method to test the signature to words method
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(signatureToWords("4221"));
		System.out.println(signatureToWords("52"));
		System.out.println(signatureToWords("1532"));
		System.out.println(signatureToWords("345515"));
		System.out.println(signatureToWords("8"));
		System.out.println(signatureToWords(" "));
	}
}
