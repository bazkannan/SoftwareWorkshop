package predictive;
/**
 * Main method to test from going to signature to list of words when referring to the
 * Predictive Prototype class containing the methods.  
 * @author Bharath
 *
 */
public class Sigs2WordsProto {
/**
 * Main method for testing our methods
 * @param args
 */
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i] + ": " + PredictivePrototype.signatureToWords(args[i]));
		}
	}

}
