package predictive;

/**
 * This is the class for the signature to words list.
 * @author Bharath
 *
 */
public class Sigs2WordsList {

	/**
	 * Main method for testing the list dictionary and calling out that method. 
	 * @param args
	 */
	public static void main(String[] args) {
		ListDictionary dictionary = new ListDictionary("src/predictive/words");
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i] + ": " + dictionary.signatureToWords(args[i]));
		}
	}
}
