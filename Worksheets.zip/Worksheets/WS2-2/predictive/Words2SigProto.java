package predictive;

/**
 * Testing the main method where we are calling the Predictive Prototype class and calling
 * the method for word to signature when printing to the console. 
 * @author Bharath
 *
 */
public class Words2SigProto {
/**
 * Main method for testing our methods
 * @param args
 */
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			System.out.println(PredictivePrototype.wordToSignature(args[i]));
		}
	}
}
