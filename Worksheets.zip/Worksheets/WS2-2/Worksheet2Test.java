import static org.junit.Assert.*;

import org.junit.Test;
/**
 * @author Bharath Kannan
 * Testing cases are shown below for each question. 
 *
 */
public class Worksheet2Test {

	 /**
	  * Testing to see if the numbers actually inverse the sign
	  */
	 @Test
	 public void testNegateAll() {
		 Tree<Integer> a1 = new Tree<Integer>(2, new Tree<Integer>(5), new Tree<Integer>(1));
		 Tree<Integer> expectedValue = new Tree<Integer>(-2, new Tree<Integer>(-5), new Tree<Integer>(-1));
		 Tree<Integer> actualValue = Worksheet2.negateAll(a1);
		 assertEquals(expectedValue, actualValue);
		 
		 Tree<Integer> a12 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     Tree<Integer> expectedResult = new Tree<>(-10,new Tree<>(-5,new Tree<>(2),new Tree<>(-7)),new Tree<>(-20, new Tree<>(-15),new Tree<>(-27)));
	     Tree<Integer> y = Worksheet2.negateAll(a12);
	     assertEquals(expectedResult, y);
	 }
	 
	 /**
	  * Testing to see if all the values in the nodes are positive. 
	  */
	 @Test
	 public void testAllPositive() {
		 Tree<Integer> a2 = new Tree<Integer>(2, new Tree<Integer>(5), new Tree<Integer>(1));
		 boolean expectedValue = true;
		 boolean actualValue = Worksheet2.allPositive(a2);
		 assertEquals(expectedValue, actualValue);
		 
		 Tree<Integer> a21 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     assertEquals(false, Worksheet2.allPositive(a21));
	    
	 }
	 
	 /**
	  * Testing to see whether the level of the node is returned for a given value. 
	  */
	 @Test
	 public void testLevel() {
		 Tree<Integer> a3 = new Tree<Integer>(2, new Tree<Integer>(5), new Tree<Integer>(1));
		 int expectedValue = 1;
		 int actualValue = Worksheet2.level(a3, 2);
		 assertEquals(expectedValue, actualValue);
		 
		 Tree<Integer> a31 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     int x = Worksheet2.level(a31, 27);
	     assertEquals(3, x);
	     assertEquals(2, Worksheet2.level(a31, 5));
	     assertEquals(1, Worksheet2.level(a31, 10));
	 } 
	 
	 /**
	  * Testing for an empty tree so it should return 0 if there are no levels displayed. 
	  */
	 @Test
	 public void testLevel2() {
		 Tree<Integer> a32 = new Tree<Integer>();
		 int expectedValue = 0;
		 int actualValue = Worksheet2.level(a32, 2);
		 assertEquals(expectedValue, actualValue);
	 } 
	 
	 /**
	  * Testing for postOrder traversal, 5 first then 1 followed by 2. 
	  */
	 @Test
	 public void testPostOrder() {
		 Tree<Integer> a4 = new Tree<Integer>(2, new Tree<Integer>(5), new Tree<Integer>(1));
		 List<Integer> expectedValue = new List<Integer>(5, new List<Integer>(1, new List<Integer>(2, new List<Integer>())));
		 List<Integer> actualValue = Worksheet2.postorder(a4);
		 assertEquals(expectedValue, actualValue);
		 
		 Tree<Integer> a41 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     List expectedX = new List(-2, new List(7, new List(5, new List(15, new List(27, new List(20, new List(10, new List ())))))));
	     List actualX = Worksheet2.postorder(a41);
	     assertEquals(expectedX, actualX);
	 }
	
	 @Test
	 public void testIsSearchTree() {
		 Tree<Integer> a5 = new Tree<Integer>(2, new Tree<Integer>(5), new Tree<Integer>(1));
		 boolean expectedValue = false;
		 boolean actualValue = Worksheet2.isSearchTree(a5, 2, 5);
		 assertEquals(expectedValue, actualValue);
		 
		 Tree<Integer> a51 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     boolean y = Worksheet2.isSearchTree(a51);
	     assertEquals(false, y);
	 }
	 
	 /**
	  * Testing for the maximum value on the right hand side. 
	  */
	 @Test
	 public void testMax() {
		 Tree<Integer> a7 = new Tree<Integer>(2, new Tree<Integer>(5), new Tree<Integer>(1));
		 int expectedValue = 1;
		 int actualValue = Worksheet2.max(a7);
		 assertEquals(expectedValue, actualValue);
		 
		 Tree<Integer> a71 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     int y = Worksheet2.max(a71);
	     assertEquals(27, y);
	 }
	 
	 @Test
	 public void testDelete() {
		 
		 Tree <Integer> a8		  = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     Tree <Integer> a8deleted = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(),new Tree<>(27)));
	     Tree <Integer> x = Worksheet2.delete(a8, 15);
	     assertEquals(x, a8deleted);
		 
		 Tree <Integer> b8 = new Tree<Integer>(2, new Tree<Integer>(1), new Tree<Integer>(5));
		 Tree <Integer> b8expectedValue = new Tree<Integer>(2, new Tree<>(1), new Tree<>());
		 Tree <Integer> b8actualValue = Worksheet2.delete(b8, 5);
	     assertEquals(b8expectedValue, b8actualValue); 
	     
	 }
	 
	/**
	 * Testing to see if the height for the trees are balanced. Returning true if it is
	 */
	 @Test
	 public void testIsHeightBalanced() {
		 Tree<Integer> a9 = new Tree<Integer>(2, new Tree<Integer>(5), new Tree<Integer>(1));
		 boolean expectedValue = true;
		 boolean  actualValue = Worksheet2.isHeightBalanced(a9);
		 assertEquals(expectedValue, actualValue);
		 
		 Tree <Integer> a91 = new Tree<>(10,new Tree<>(5,new Tree<>(-2),new Tree<>(7)),new Tree<>(20, new Tree<>(15),new Tree<>(27)));
	     boolean x = Worksheet2.isHeightBalanced(a91);
	     assertEquals(x, true);
	    
	 }
	 
	 /**
	  * Testing to see if height is balanced for empty tree.
	  */
	 @Test
	 public void testIsHeightBalancedEmpty() {
		 Tree<Integer> a92 = new Tree<Integer>();
		 boolean expectedValue = true;
		 boolean  actualValue = Worksheet2.isHeightBalanced(a92);
		 assertEquals(expectedValue, actualValue);
	 }
}
