package predictive;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.io.IOException;

import predictive.PredictivePrototype;

/**
 * Question 2 of the worksheet below are the solutions.  
 * @author Bharath
 *
 */
public class ListDictionary implements Dictionary {
	
	/* Writing a constructor for the class that takes a String path to the dictionary
 * and reads it as ArrayList. 
 * SignatureToWords rewritten as an instance method in the ListDictionary class
 * to use the stored dictionary
 * ArrayList<WordSig> stored in sorted order and signatureToWords use
 * binary search to perform the look-ups.  */
	
	private ArrayList <WordSig> dictionary;
	/**
	 * Constructor for the list dictionary. We use a try catch statement
	 * Using the scanner to scan the file for dictionary 
	 * Using the while loop to loop through the scanner input. 
	 * @param dictionaryFile
	 */
	public ListDictionary (String dictionaryFile) {
		dictionary = new ArrayList<WordSig>();
		
		try { 
			Scanner input = new Scanner(new File(dictionaryFile));
		while (input.hasNext()) {
			String line = input.nextLine().toLowerCase();
			if (PredictivePrototype.isValidWord(line)) {
				String s = PredictivePrototype.wordToSignature(line);
				WordSig newWordSig = new WordSig(line, s);
				dictionary.add(newWordSig);
			}
		}
		input.close();
	} catch (IOException e) {
		System.out.println("Can't find the file");
	}
	Collections.sort(dictionary);
}
	
	/**
	 * The method for signature to words, writing it as a collection and binary search 
	 */
	public Set<String> signatureToWords (String signature) {
		Set<String> output = new TreeSet<String>();
		
		if (signature.length() == 0) {
			return output;
		}
		WordSig key = new WordSig(null, signature);
		
		int index = Collections.binarySearch(dictionary,  key);
		if (index > 0 && dictionary.get(index).getSignature().equals(signature)) {
			output.add(dictionary.get(index).getWords());
			
			for (int i = index -1; i > 0 && dictionary.get(i).getSignature().equals(signature); i--) {
				output.add(dictionary.get(i).getWords());
			} for (int i = index + 1; i < dictionary.size() && dictionary.get(i).getSignature().equals(signature); i++) {
				output.add(dictionary.get(i).getWords());
			}
		} return output;
	}
	
	/**
	 * Main method for testing our list dictionary 
	 * @param args
	 */
	public static void main(String[]args) {
		ListDictionary a = new ListDictionary("src/predictive/words");
		System.out.println(a.signatureToWords("42"));
		System.out.println(a.signatureToWords("3"));
	}
}
