package predictive;

/**
 * This is the class for the words signature and implementing the comparable interface. 
 * Getters and setters are displayed for the words and signature
 * @author Bharath
 *
 */
public class WordSig implements Comparable <WordSig> {
	
	private String words;
	private String signature;
	
	/**
	 * Constructor for the word and signature. 
	 * @param words
	 * @param signature
	 */
	public WordSig(String words, String signature) {
		this.words = words;
		this.signature = signature;
	}
	
	public String getWords() {
		return words;
	}
	
	public String getSignature() {
		return signature; 
	}

	/**
	 * The compare to method where you compare the words and signature and returning the values. 
	 */
	@Override
	public int compareTo(WordSig ws) {
		return this.signature.compareTo(ws.signature);
		/* if (this.signature.length() > ws.signature.length()) {
			return 1;
		} else if (this.signature.length() < ws.signature.length()) {
			return -1;
		} else {
			return this.signature.compareTo(ws.signature);
		} */
	}
	
	/**
	 * To string method to return the signature and words. 
	 */
	public String toString() {
		return "Signature: " + signature + "Words: " + words;
	}
}
