package predictive;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.io.*;
import java.lang.System;
import java.nio.file.Paths;

/**
 * This class contains the solutions for the Worksheet 3, question 1. 
 * @author Bharath
 *
 */
public class PredictivePrototype {
	
	/**
	 * Method to change the words to signature. 
	 * @param words
	 * @return words.toString()
	 */
	
	public static String wordToSignature(String word) {
		

		StringBuffer signature = new StringBuffer();
		
		// Looping through the words in the predictive text
		for (int i = 0; i < word.length(); i++) {
			
			if ((word.charAt(i) == ('a')) || (word.charAt(i) == ('A')) || (word.charAt(i) == ('b')) || (word.charAt(i) == ('B')) || (word.charAt(i) == ('c')) || (word.charAt(i) == ('C'))) {
				signature.append(2);
			} else if ((word.charAt(i) == ('d')) || (word.charAt(i) == ('D')) || (word.charAt(i) == ('e')) || (word.charAt(i) == ('E')) || (word.charAt(i) == ('f'))|| (word.charAt(i) == ('F'))) {
				signature.append(3);
			} else if ( (word.charAt(i) == ('g'))|| (word.charAt(i) == ('G')) || (word.charAt(i) == ('h')) || (word.charAt(i) == ('H')) || (word.charAt(i) == ('i')) || (word.charAt(i) == ('I'))) {
				signature.append(4);
			} else if ((word.charAt(i) == ('j')) || (word.charAt(i) == ('J')) || (word.charAt(i) == ('k')) || (word.charAt(i) == ('K')) || (word.charAt(i) == ('l')) || (word.charAt(i) == ('L'))) {
				signature.append(5);
			} else if ((word.charAt(i) == ('m')) || (word.charAt(i) == ('M')) || (word.charAt(i) == ('n')) || (word.charAt(i) == ('N')) || (word.charAt(i) == ('o')) || (word.charAt(i) == ('O'))) {
				signature.append(6);
			} else if ((word.charAt(i) == ('p')) || (word.charAt(i) == ('P')) || (word.charAt(i) == ('q')) || (word.charAt(i) == ('Q')) || (word.charAt(i) == ('r')) || (word.charAt(i) == ('R')) || (word.charAt(i) == ('s')) || (word.charAt(i) == ('S'))) {
				signature.append(7);
			} else if ((word.charAt(i) == ('t')) || (word.charAt(i) == ('T')) || (word.charAt(i) == ('u')) || (word.charAt(i) == ('U')) || (word.charAt(i) == ('v')) || (word.charAt(i) == ('V'))) {
				signature.append(8);
			} else if ((word.charAt(i) == ('w')) || (word.charAt(i) == ('W')) || (word.charAt(i) == ('x')) || (word.charAt(i) == ('X')) || (word.charAt(i) == ('y')) || (word.charAt(i) == ('Y')) || (word.charAt(i) == ('z')) || (word.charAt(i) == ('Z'))) {
				signature.append(9);
			} else {
				signature.append(" ");
			}
		} 
		return signature.toString();
	} 
	
	/**
	 * Helper method which contains an enhanced for loop. Looping through
	 * the array of characters. If the character is a letter, return true 
	 * otherwise return false. 
	 * @param word
	 * @return
	 * 
	 */
	static boolean isValidWord(String word) {
		for (char c : word.toCharArray()) {
			if (!Character.isLetter(c)) {
				return false;
			} 
	} return true;
}
	
	/**
	 * Why the implementation of storing the dictionary in your java program is inefficient. 
	 * Takes up unnecessary power, want to store less information in the JVM.  
	 * @param signature
	 * @return
	 */
	public static Set<String> signatureToWords(String signature) {
		
		Set<String> set = new HashSet<String>();
		Scanner input;
		
		try {
		input = new Scanner(Paths.get("src/predictive/words"));
		
		while(input.hasNext()) {
			String word = input.nextLine();
			if (isValidWord(word)) {
				String sig = wordToSignature(word);
				if (signature.equals(sig)) {
					set.add(word.toLowerCase());
				}
			}
		}
		input.close(); // Closing the scanner so that it's not taking up memory for JVM 
	} catch (IOException e) {
		System.out.println("Not found");
	} return set;
}

	/**
	 * Main method to test the signature to words method
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(isValidWord("hello"));
		System.out.println(isValidWord("9aa9"));
    	System.out.println(signatureToWords("42"));
    	System.out.println(wordToSignature("gone"));
	}
}
