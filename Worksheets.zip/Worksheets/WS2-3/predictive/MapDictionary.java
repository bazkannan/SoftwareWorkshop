package predictive;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 * This is the solution for Question 3 of the Worksheet 3. 
 * @author Bharath
 *
 */
public class MapDictionary implements Dictionary {
	
	private Map <String, Set<String>> dictionary;
	
	/**
	 * Constructor for the map dictionary 
	 * @param mapDictionary
	 */
	public MapDictionary(String mapDictionary) {
		dictionary = new HashMap<String, Set<String>>();
		
		try {
			Scanner input = new Scanner(new File(mapDictionary));
			
			while (input.hasNext()) {
				String word = input.nextLine().toLowerCase();
				if (PredictivePrototype.isValidWord(word)) {
					this.addWord(word);
				}
			}
			input.close();
			
		} catch (FileNotFoundException e) {
			System.out.println("Not found");		
	}
}
	
	/**
	 * A method that converts the word to a signature, loops through the dictionary. 
	 * @param word
	 * @return
	 */
	public static String wordToSignature(String word) {
	
	StringBuffer signature = new StringBuffer();
	
	// Looping through the words in the predictive text
	for (int i = 0; i < word.length(); i++) {
		
		if ((word.charAt(i) == ('a')) || (word.charAt(i) == ('A')) || (word.charAt(i) == ('b')) || (word.charAt(i) == ('B')) || (word.charAt(i) == ('c')) || (word.charAt(i) == ('C'))) {
			signature.append(2);
		} else if ((word.charAt(i) == ('d')) || (word.charAt(i) == ('D')) || (word.charAt(i) == ('e')) || (word.charAt(i) == ('E')) || (word.charAt(i) == ('f'))|| (word.charAt(i) == ('F'))) {
			signature.append(3);
		} else if ( (word.charAt(i) == ('g'))|| (word.charAt(i) == ('G')) || (word.charAt(i) == ('h')) || (word.charAt(i) == ('H')) || (word.charAt(i) == ('i')) || (word.charAt(i) == ('I'))) {
			signature.append(4);
		} else if ((word.charAt(i) == ('j')) || (word.charAt(i) == ('J')) || (word.charAt(i) == ('k')) || (word.charAt(i) == ('K')) || (word.charAt(i) == ('l')) || (word.charAt(i) == ('L'))) {
			signature.append(5);
		} else if ((word.charAt(i) == ('m')) || (word.charAt(i) == ('M')) || (word.charAt(i) == ('n')) || (word.charAt(i) == ('N')) || (word.charAt(i) == ('o')) || (word.charAt(i) == ('O'))) {
			signature.append(6);
		} else if ((word.charAt(i) == ('p')) || (word.charAt(i) == ('P')) || (word.charAt(i) == ('q')) || (word.charAt(i) == ('Q')) || (word.charAt(i) == ('r')) || (word.charAt(i) == ('R')) || (word.charAt(i) == ('s')) || (word.charAt(i) == ('S'))) {
			signature.append(7);
		} else if ((word.charAt(i) == ('t')) || (word.charAt(i) == ('T')) || (word.charAt(i) == ('u')) || (word.charAt(i) == ('U')) || (word.charAt(i) == ('v')) || (word.charAt(i) == ('V'))) {
			signature.append(8);
		} else if ((word.charAt(i) == ('w')) || (word.charAt(i) == ('W')) || (word.charAt(i) == ('x')) || (word.charAt(i) == ('X')) || (word.charAt(i) == ('y')) || (word.charAt(i) == ('Y')) || (word.charAt(i) == ('z')) || (word.charAt(i) == ('Z'))) {
			signature.append(9);
		} else {
			signature.append(" ");
		}
	} 
	return signature.toString();
} 

	/**
	 * A method that will add the word to the tree set. PUt the words
	 * in the dictionary. 
	 * @param word
	 */
	private void addWord(String word) {
		Set<String> words = dictionary.get(PredictivePrototype.wordToSignature(word));
		
		if (words != null) {
			words.add(word);
		} else {
			words = new TreeSet<String>();
			words.add(word);
			dictionary.put(PredictivePrototype.wordToSignature(word), words);
		}
	}

	@Override
	public Set<String> signatureToWords(String signature) {
			return dictionary.get(signature);
		}
		
	/**
	 * Main method to test the solutions for the map dictionary. 
	 * @param args
	 */
	public static void main(String [] args) {
		MapDictionary d = new MapDictionary("src/predictive/words");
    	System.out.println(wordToSignature("gone"));
    	System.out.println(d.signatureToWords("4663"));
	}
}
