package predictive;

/**
 * Class to run the mapDictionary program through the command line. 
 * @author Bharath
 *
 */
public class Sigs2WordsMap {
	
	/**
	 * Main method to test this. 
	 * @param args
	 */
	public static void main(String[] args) {
		
		Dictionary dict = new MapDictionary(null);
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i] + ": " + dict.signatureToWords(args[i]));
		}
	}
}
