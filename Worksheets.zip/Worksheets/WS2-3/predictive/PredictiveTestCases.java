package predictive;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
/**
 * J Unit testing for these classes in the predictive prototype and dictionaries. 
 * @author Bharath
 *
 */
public class PredictiveTestCases {

	@Test
	public void test1() {
		boolean expectedValue = false;
		boolean actualValue = PredictivePrototype.isValidWord("9aa9");
		assertEquals(expectedValue, actualValue);
	}
	
	@Test
	public void test2() {
		 boolean expectedValue = true;
		 boolean actualValue = PredictivePrototype.isValidWord("hello");
		 assertEquals(expectedValue, actualValue);
	 }
	
	@Test
	public void test3() {
		Set <String> set1 = new HashSet <String>();;
		
		set1.add("ia");
		set1.add("ha");
		set1.add("ib");
		set1.add("ga");
		set1.add("hb");
		set1.add("ic");
		set1.add("gb");
		set1.add("hc");
		set1.add("gc");
		
		Set <String> actualValue = PredictivePrototype.signatureToWords("42");
		assertEquals(set1, actualValue);
	}
	
	@Test
	public void test4() {
		String expectedValue = "4663";
		String actualValue = PredictivePrototype.wordToSignature("gone");
		assertEquals(expectedValue, actualValue);
	}
	
}
