package predictive;

/**
 * This is the class in which we test the method for the tree dictionary through
 * the command line. 
 * @author Bharath
 *
 */
public class Sigs2WordsTree {

	/**
	 * Calling out the method for tree dictionary
	 * @param args
	 */
	public static void main(String[] args) {
		Dictionary dictionary = new TreeDictionary("src/predictive/words");
        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i] + " : " + dictionary.signatureToWords(args[i]));
        }
	}
}
