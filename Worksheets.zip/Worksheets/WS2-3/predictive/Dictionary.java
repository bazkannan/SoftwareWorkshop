package predictive;

import java.util.Set;
/**
 * This is the interface for the Dictionary in which all the classes for list, map and tree will implement this
 * @author Bharath
 *
 */
public interface Dictionary {
	public Set<String> signatureToWords(String signature);
}
