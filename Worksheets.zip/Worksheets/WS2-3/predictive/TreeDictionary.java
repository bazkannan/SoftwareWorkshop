package predictive;

import java.util.Set;
import java.util.TreeSet;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;

/**
 * The class for the TreeDictionary which has words in an array.
 * This will return the word or signature depending on the values for
 * eahc node. 
 * @author Bharath
 *
 */
public class TreeDictionary implements Dictionary {
	
	private Set<String> words;
	
	
	/**
	 * Constructor for the tree dictionary. 
	 * @param treeDictionary
	 */
	public TreeDictionary(String treeDictionary) {
		words = new TreeSet<String>();
		try {
			Scanner input = new Scanner(new File(treeDictionary));
			while (input.hasNext()) {
			String word = input.nextLine().toLowerCase();
			
			if (PredictivePrototype.isValidWord(word)) {
				PredictivePrototype.isValidWord(word);
			} else {
				return;
			}
			input.close();
			}
		} catch (FileNotFoundException e) {
			System.out.println("Not found");
		}
	}
	
	/**
	 * Helper function for the tree
	 * @param signature
	 * @param word
	 * @param count
	 */
	public void insertHelperFunction (String signature, String word, int count) {
		if (signature.length() == count) {
			words.add(word);
		}
	}
	
	/**
	 * Insert method which makes use of the helper function to insert the signature
	 * @param word
	 * @param signature
	 */
	public void insert(String word, String signature) {
		if (PredictivePrototype.isValidWord(word) && signature.length() > 0) {
			insertHelperFunction(signature, word, 0);
		}
	}
	
	/**
	 * Signature to words method for the tree dictionary. 
	 */
	public Set<String> signatureToWords(String signature) {
		Set<String> output = new TreeSet<String>();
		
		for (String word : output) {
			output.add(word.substring(0, signature.length()));
		}
		return output;
	}
	
	/**
	 * Main method to test for our solutions 
	 * @param args
	 */
	public static void main(String [] args) {
		ListDictionary dictionary = new ListDictionary("src/predictive/words");
        System.out.println(dictionary.signatureToWords("4221"));
        System.out.println(dictionary.signatureToWords(" "));
	}
	
}


